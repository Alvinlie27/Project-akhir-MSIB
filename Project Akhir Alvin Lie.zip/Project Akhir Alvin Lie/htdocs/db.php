<?php
$host = "localhost";        // Host server MySQL, biasanya 'localhost'
$user = "root";             // Username MySQL, default di XAMPP adalah 'root'
$password = "";             // Password MySQL, default kosong di XAMPP
$dbname = "finance_db";     // Nama database yang sudah dibuat di phpMyAdmin

// Membuat koneksi ke database
$conn = new mysqli($host, $user, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
