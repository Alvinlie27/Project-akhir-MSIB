const form = document.getElementById('transaction-form');
const transactionList = document.getElementById('transaction-list');
const totalIncomeElement = document.getElementById('total-income');
const totalExpenseElement = document.getElementById('total-expense');
const balanceElement = document.getElementById('balance');

let transactions = [];

form.addEventListener('submit', (event) => {
    event.preventDefault();

    const description = document.getElementById('description').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const type = document.getElementById('type').value;

    const transaction = {
        description,
        amount,
        type
    };

    transactions.push(transaction);
    updateUI();
    form.reset();
});

function updateUI() {
    // Reset transaction list
    transactionList.innerHTML = '';

    let totalIncome = 0;
    let totalExpense = 0;

    transactions.forEach((transaction) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.description}</td>
            <td>Rp ${transaction.amount.toLocaleString()}</td>
            <td>${transaction.type === 'income' ? 'Pemasukan' : 'Pengeluaran'}</td>
        `;
        transactionList.appendChild(row);

        if (transaction.type === 'income') {
            totalIncome += transaction.amount;
        } else {
            totalExpense += transaction.amount;
        }
    });

    const balance = totalIncome - totalExpense;

    totalIncomeElement.textContent = `Rp ${totalIncome.toLocaleString()}`;
    totalExpenseElement.textContent = `Rp ${totalExpense.toLocaleString()}`;
    balanceElement.textContent = `Rp ${balance.toLocaleString()}`;
}
